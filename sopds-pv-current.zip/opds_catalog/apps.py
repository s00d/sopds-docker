from django.apps import AppConfig


class OpdsCatalogConfig(AppConfig):
    name = 'opds_catalog'
