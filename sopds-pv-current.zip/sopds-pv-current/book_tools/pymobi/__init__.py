
__author__ = 'Yugang LIU'
__email__ = 'liuyug@gmail.com'
__version__ = '0.1.3'
__license__ = 'GPLv3'


from book_tools.pymobi.mobi import BookMobi
from book_tools.pymobi.util import *
