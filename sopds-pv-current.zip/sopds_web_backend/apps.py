from django.apps import AppConfig


class SopdsWebBackendConfig(AppConfig):
    name = 'sopds_web_backend'
